-- Draft skema awal; review dan uji RLS sebelum produksi.
-- Jangan membuka tabel orders untuk SELECT publik.
create extension if not exists pgcrypto;

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  platform text not null check (platform in ('instagram','tiktok','youtube')),
  description text,
  price_per_unit numeric(12,2) not null default 0 check (price_per_unit >= 0),
  is_active boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_code text unique not null,
  platform text not null check (platform in ('instagram','tiktok','youtube')),
  content_url text not null,
  campaign_type text not null,
  notes text,
  amount_idr numeric(12,2) not null default 0 check (amount_idr >= 0),
  status text not null default 'pending'
    check (status in ('pending','awaiting_payment','paid','processing','completed','cancelled','refunded')),
  created_at timestamptz not null default now()
);

alter table public.services enable row level security;
alter table public.orders enable row level security;

-- Belum ada policy publik dengan sengaja.
-- Akses order harus melalui Edge Function/server dengan validasi dan rate limit.
-- Admin policies ditambahkan setelah skema autentikasi admin ditentukan.
