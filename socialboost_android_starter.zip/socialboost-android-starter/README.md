# SocialBoost - Starter untuk Android

Ini adalah starter frontend statis. Formulir saat ini hanya demo browser; belum ada database, akun admin, pemrosesan order, provider promosi, atau pembayaran QRIS. Jangan menerima uang pelanggan atau memasarkan layanan sebagai aktif sebelum backend dan pembayaran diuji.

## Cara termudah dari HP Android

1. Unduh ZIP ini dan ekstrak dengan aplikasi Files / ZArchiver.
2. Buka Chrome dan masuk ke https://github.com lalu buat akun atau login.
3. Buat repository baru bernama `socialboost` dan pilih **Public** (atau Private jika ingin menyimpan kode secara privat).
4. Di repository, pilih **Add file → Upload files**, unggah `index.html` dari folder ini. Commit perubahan.
5. Untuk melihat website demo: buka **Settings → Pages**, pilih **Deploy from a branch**, branch `main`, folder `/root`, lalu Save. Tunggu proses publikasi. URL akan muncul di halaman Pages.

Alternatif deployment: impor repository ke https://vercel.com melalui browser HP. Untuk situs statis ini, Vercel dapat melayani `index.html` sebagai halaman utama.

## Tahap backend berikutnya

- Buat proyek Supabase di https://supabase.com.
- Buat tabel orders, services, payment_events, dan admin_users dengan Row Level Security.
- Buat endpoint server/Edge Function untuk validasi URL, rate limit, membuat nomor order, dan menyimpan pesanan.
- Jangan pernah menaruh `service_role` key, secret payment gateway, atau kredensial provider di HTML/browser.
- Integrasikan QRIS dinamis lewat akun merchant payment gateway. Verifikasi status pembayaran memakai webhook server-to-server, bukan screenshot pelanggan.
- Tambahkan panel admin yang dilindungi autentikasi dan audit log.

## Batas layanan

Gunakan kampanye iklan/promosi resmi atau layanan yang diizinkan platform. Jangan menjual engagement palsu, bot followers, atau menjanjikan metrik yang dimanipulasi. Periksa ketentuan Instagram, TikTok, dan YouTube sebelum mengaktifkan layanan.
